<template>
  <div>
    银保监会处罚公示
  </div>
</template>
