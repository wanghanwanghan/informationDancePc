<template>
  <div>
    外汇局处罚
  </div>
</template>
