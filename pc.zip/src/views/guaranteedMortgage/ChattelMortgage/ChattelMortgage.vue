<template>
  <div>
    动产抵押
  </div>
</template>
