<template>
  <div>
    行政处罚
  </div>
</template>
