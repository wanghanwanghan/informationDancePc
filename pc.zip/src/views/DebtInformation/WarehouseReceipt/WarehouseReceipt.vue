<template>
  <div>
    仓单质押登记
  </div>
</template>
