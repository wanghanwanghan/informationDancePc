<template>
  <div>
    租赁登记
  </div>
</template>
