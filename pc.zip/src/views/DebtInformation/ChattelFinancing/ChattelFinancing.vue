<template>
  <div>
    其他动产融资
  </div>
</template>
