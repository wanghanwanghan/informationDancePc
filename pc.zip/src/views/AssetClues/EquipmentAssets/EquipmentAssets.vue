<template>
  <div>
    设备资产类
  </div>
</template>
