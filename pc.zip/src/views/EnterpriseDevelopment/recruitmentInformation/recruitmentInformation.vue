<template>
  <div>
    招聘信息
  </div>
</template>
