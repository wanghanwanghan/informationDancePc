<template>
  <div>
    建筑资格证书
  </div>
</template>
