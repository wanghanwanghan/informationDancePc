<template>
  <div>
    购地信息
  </div>
</template>
