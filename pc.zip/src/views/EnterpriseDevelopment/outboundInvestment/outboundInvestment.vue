<template>
  <div>
    对外投资
  </div>
</template>
