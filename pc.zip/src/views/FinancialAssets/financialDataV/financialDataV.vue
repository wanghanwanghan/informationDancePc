<template>
  <div>
    财务数据（需授权）
  </div>
</template>
